package junit.test;

import java.util.Date;

import org.junit.Test;

import me.test.dao.impl.CustomerDaoImpl;
import me.test.domain.Customer;

public class CustomerDaoImplTest {

    @Test
    public void testAdd() {
        CustomerDaoImpl customer = new CustomerDaoImpl();
        Customer c = new Customer();
        c.setId("1");
        c.setName("����");
        c.setGender("��");
        c.setBirthday(new Date());
        c.setCellphone("18682919679");
        c.setEmail("123@test.me");
        c.setPreference("����Ӱ");
        c.setType("��Ҫ�ͻ�");
        c.setDescription("��ע");
        
        customer.add(c);
        System.out.println("����ɹ�");
    }

}
