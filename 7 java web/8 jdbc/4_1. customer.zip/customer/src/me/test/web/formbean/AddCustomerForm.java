package me.test.web.formbean;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.locale.converters.DateLocaleConverter;

public class AddCustomerForm {
    
    private String name;
    private String gender;
    private String birthday;
    private String cellphone;
    private String email;
    private String preference;
    private String type;
    private String description;
    
    private Map errors = new HashMap(); // ����һ������������У��ʧ�ܵ���Ϣ

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getCellphone() {
        return cellphone;
    }

    public void setCellphone(String cellphone) {
        this.cellphone = cellphone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPreference() {
        return preference;
    }

    public void setPreference(String preference) {
        this.preference = preference;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Map getErrors() {
        return errors;
    }

    public void setErrors(Map errors) {
        this.errors = errors;
    }
    
    // �ύ����У��
    
    /*private String name;
    private String gender;
    private String birthday;
    private String cellphone;
    private String email;
    private String preference;
    private String type;
    private String description;*/
    
    public boolean validate() {
        boolean isOK = true;
        
        if(this.name == null || this.name.trim().equals("")) {
            isOK = false;
            errors.put("name", "�û���������Ϊ��");
        }
        
        if(this.gender == null || this.gender.trim().equals("")) {
            isOK = false;
            errors.put("gender", "�Ա���Ϊ��");
        }
        
     // ���ڵ�У�飬Ҫ�������ύ���ַ���ת��Ϊ���ڸ�ʽ�����жϣ���ת�����ڲ��׳��쳣������ȷ��ʽ
        if(this.birthday != null && !this.birthday.trim().equals("")) {
            try {
                DateLocaleConverter dlc = new DateLocaleConverter();
                dlc.convert(this.birthday, "yyyy-MM-dd");
            }catch(Exception e) {
                isOK = false;
                errors.put("birthday", "���ڸ�ʽ����");
            }
            
        }
        
        if(this.cellphone.trim().equals("")) {
            isOK = false;
            errors.put("cellphone", "�ֻ��Ų���Ϊ�ո�");
        }
        
        if(this.email == null || this.email.trim().equals("")) {
            isOK = false;
            errors.put("email", "���䲻��Ϊ��");
        }else {
            // �����ʽ  �����ַ������Զ���ظ����֣�@�����ַ�+".+�����ַ�������ظ���"
            // \\w+@\\w+(\\.\\w+)+
            if(!this.email.matches("\\w+@\\w+(\\.\\w+)+")) {
                isOK = false;
                errors.put("email", "�����ʽ����");
            }
        }
        
        if(this.preference == null || this.preference.trim().equals("")) {
            isOK = false;
            errors.put("preference", "���ò���Ϊ��");
        }
        
        if(this.type == null || this.type.trim().equals("")) {
            isOK = false;
            errors.put("type", "���Ͳ���Ϊ��");
        }
        
        return isOK;
    }
    
}
