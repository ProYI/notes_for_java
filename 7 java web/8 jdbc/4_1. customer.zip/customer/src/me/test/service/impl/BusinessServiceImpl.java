package me.test.service.impl;

import java.util.List;

import me.test.dao.CustomerDao;
import me.test.dao.impl.CustomerDaoImpl;
import me.test.domain.Customer;
import me.test.service.BusinessService;

public class BusinessServiceImpl implements BusinessService {

    private CustomerDao dao = new CustomerDaoImpl();
    
    @Override
    public void addCustomer(Customer c) {
        dao.add(c);  
    }
    
    @Override
    public void updateCustomer(Customer c) {
        dao.update(c);  
    }
    
    @Override
    public void deleteCustomer(String id) {
        dao.delete(id);;  
    }
    
    @Override
    public Customer findCustomer(String id) {
        return dao.find(id);  
    }
    
    @Override
    public List<Customer> getAllCustomer() {
        return dao.getAll();  
    }
}
