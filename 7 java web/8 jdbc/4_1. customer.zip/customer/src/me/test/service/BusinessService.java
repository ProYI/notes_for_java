package me.test.service;

import java.util.List;

import me.test.domain.Customer;

public interface BusinessService {

    void addCustomer(Customer c);

    void updateCustomer(Customer c);

    void deleteCustomer(String id);

    Customer findCustomer(String id);

    List<Customer> getAllCustomer();

}