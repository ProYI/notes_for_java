package me.test.dao;

import java.util.List;

import me.test.domain.Customer;
import me.test.domain.QueryResult;

public interface CustomerDao {

    void add(Customer c);

    void update(Customer c);

    void delete(String id);

    Customer find(String id);

    List<Customer> getAll();

    QueryResult pageQuery(int startindex, int pagesize);
}