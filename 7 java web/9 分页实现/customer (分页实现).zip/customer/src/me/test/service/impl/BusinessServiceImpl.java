package me.test.service.impl;

import java.util.List;

import me.test.dao.CustomerDao;
import me.test.dao.impl.CustomerDaoImpl;
import me.test.domain.Customer;
import me.test.domain.PageBean;
import me.test.domain.QueryInfo;
import me.test.domain.QueryResult;
import me.test.service.BusinessService;

public class BusinessServiceImpl implements BusinessService {

    private CustomerDao dao = new CustomerDaoImpl();
    
    @Override
    public void addCustomer(Customer c) {
        dao.add(c);  
    }
    
    @Override
    public void updateCustomer(Customer c) {
        dao.update(c);  
    }
    
    @Override
    public void deleteCustomer(String id) {
        dao.delete(id);;  
    }
    
    @Override
    public Customer findCustomer(String id) {
        return dao.find(id);  
    }
    
    @Override
    public List<Customer> getAllCustomer() {
        return dao.getAll();  
    }
    
    public PageBean pageQuery(QueryInfo queryInfo) {
        
        //����dao��ȡ��ҳ������
        QueryResult qr = dao.pageQuery(queryInfo.getStartindex(), queryInfo.getPagesize());
        
        //����dao��ѯ���������ҳ����ʾ��Ҫpagebean
        PageBean bean = new PageBean();
        bean.setCurrentpage(queryInfo.getCurrentpage());
        bean.setList(qr.getList());
        bean.setPagesize(queryInfo.getPagesize());
        bean.setTotalrecord(qr.getTotalrecord());
        
        return bean;
    }
}
