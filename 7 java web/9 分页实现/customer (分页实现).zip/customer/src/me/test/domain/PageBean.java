package me.test.domain;

import java.util.List;

// ��װҳ����ʾ�Ķ���
public class PageBean {

    private List list; //ҳ����ʾ����
    private int totalrecord; //�ܼ�¼��
    private int pagesize; //ÿҳ������
    private int totalpage; //�ܹ�����ҳ
    private int currentpage; //��ǰ�ڼ�ҳ
    private int previouspage; //��һҳ
    private int nextpage;  //��һҳ
    private int[] pagebar; //ҳ����
    
    // ͨ��QueryResult����List���ݡ��ܼ�¼����ҳ������
    public List getList() {
        return list;
    }
    public void setList(List list) {
        this.list = list;
    }
    public int getTotalrecord() {
        return totalrecord;
    }
    public void setTotalrecord(int totalrecord) {
        this.totalrecord = totalrecord;
    }
    public int getPagesize() {
        return pagesize;
    }
    public void setPagesize(int pagesize) {
        this.pagesize = pagesize;
    }
    
    // ����ͨ���ܼ�¼�ͷ�ҳ����������������Բ����Ⱪ¶set����
    public int getTotalpage() {
        
        /*
         �����¼100����ÿҳ��ʾ5��    totalpageΪ20ҳ
         101����ÿҳ��ʾ5��    totalpageΪ21ҳ
         99����ÿҳ��ʾ5��    totalpageΪ20ҳ
         */
        
        if(this.totalrecord%this.pagesize == 0) {
            this.totalpage = this.totalrecord/this.pagesize;
        } else {
            this.totalpage = this.totalrecord/this.pagesize + 1;
        }
        return totalpage;
    }

    public int getCurrentpage() {
        return currentpage;
    }
    public void setCurrentpage(int currentpage) {
        this.currentpage = currentpage;
    }
    
    public int getPreviouspage() {
        if(this.currentpage -1 < 1) {
            this.previouspage = 1;
        } else {
            this.previouspage = this.currentpage -1;
        }
        return previouspage;
    }

    public int getNextpage() {
        if(this.currentpage +1 >= this.totalpage) {
            this.nextpage = this.totalpage;
        } else {
            this.nextpage = this.currentpage + 1;
        }
        return nextpage;
    }
    
    public int[] getPagebar() {
        
        /*int pagebar[] = new int[this.totalpage];
        for(int i=1;i<=this.totalpage;i++){
            pagebar[i-1] = i;
        }
        this.pagebar = pagebar;
        return pagebar;*/
        
        int startpage;
        int endpage;
        int pagebar[] = null;
        
        if(this.totalpage <= 5) {
            pagebar = new int[this.totalpage];
            startpage = 1;
            endpage = this.totalpage;
        } else {
            pagebar = new int[6];
            startpage = this.currentpage -2;
            endpage = this.currentpage + 3;
            
            if(startpage < 1) {
                startpage = 1;
                endpage = 6;
            }
            
            if(endpage > this.totalpage) {
                endpage = totalpage;
                startpage = this.totalpage - 5;
            }
        }
        
        int index = 0;
        for(int i = startpage;i <= endpage;i++) {
            pagebar[index++] = i;
        }
        this.pagebar = pagebar;
        return pagebar;
    }

}
