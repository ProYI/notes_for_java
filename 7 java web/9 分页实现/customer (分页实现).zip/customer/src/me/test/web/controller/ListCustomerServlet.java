package me.test.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import me.test.domain.PageBean;
import me.test.domain.QueryInfo;
import me.test.service.BusinessService;
import me.test.service.impl.BusinessServiceImpl;
import me.test.utils.WebUtils;

//�����û���ҳ���� 
@WebServlet("/servlet/ListCustomerServlet")
public class ListCustomerServlet extends HttpServlet {
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    
	    try{
            QueryInfo info = WebUtils.request2Bean(request, QueryInfo.class);
            BusinessService service = new BusinessServiceImpl();
            PageBean pagebean = service.pageQuery(info);
            request.setAttribute("pagebean", pagebean);
            request.getRequestDispatcher("/WEB-INF/jsp/listcustomer.jsp").forward(request, response);
        }catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "�鿴�ͻ�ʧ�ܣ���");
            request.getRequestDispatcher("/message.jsp").forward(request, response);
        }
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
